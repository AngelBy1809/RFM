# -*- coding: UTF-8 -*-

import pandas as pd
import numpy as np
from urllib.request import urlopen
from bs4 import BeautifulSoup
from urllib.error import HTTPError
import ssl
import pandas as pd
import numpy as np



def url_parsing(url):
    try:
        context = ssl._create_unverified_context()
        html0 = urlopen(url, context=context)
    except HTTPError as e:
        return None
    try:
        bsObj1 = BeautifulSoup(html0.read(), features="lxml")
    except AttributeError as e:
        return None
    return bsObj1


M = []
def single_url(url):
    tt = url_parsing(url)
    if tt is None:
        print("the page does exisit!")
    else:
        flag0 = 0
        while flag0 < 30:
            dt = tt.findAll(class_='title')[flag0]
            dt2 = tt.findAll("div", class_="houseInfo")[flag0]
            dt3 = tt.findAll("div", class_="positionInfo")[flag0]
            dt4 = tt.findAll("div", class_="totalPrice")[flag0]
            dt5 = tt.findAll("div", class_="unitPrice")[flag0]
            dt6 = tt.findAll("div", class_="followInfo")[flag0]
            dt7 = tt.findAll("div", class_="tag")[flag0]
            houseName = dt.get_text()
            houseURL = dt['href']
            houseArea = dt2.get_text()
            houseBuiltDate = dt3.get_text()
            houseTotalPrice = dt4.get_text()
            houseUnitPrice = dt5.get_text()
            houseOthers = dt6.get_text()
            houseOthers2 = dt7.get_text()
            M.append(houseName)
            M.append(houseURL)
            M.append(houseArea)
            M.append(houseBuiltDate)
            M.append(houseTotalPrice)
            M.append(houseUnitPrice)
            M.append(houseOthers)
            M.append(houseOthers2)
            print(houseName, ",", houseURL, ",", houseArea, ",", houseBuiltDate, ",", houseTotalPrice, ",", houseUnitPrice, ",", houseOthers, ",", houseOthers2)
            print(flag0)
            flag0 = flag0 + 1
    return M


ff = 2
while ff < 202:
    nn = single_url('https://hz.lianjia.com/ershoufang/pg' + str(ff) + '/')
    nn = pd.DataFrame(np.array(nn).reshape(30, 8), columns=None)
    nn.to_csv('house01.csv', index=True, sep=',', mode='a')
    M = []
    ff = ff + 1
